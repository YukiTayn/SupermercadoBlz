package sm.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class GerentesController {

	
}
